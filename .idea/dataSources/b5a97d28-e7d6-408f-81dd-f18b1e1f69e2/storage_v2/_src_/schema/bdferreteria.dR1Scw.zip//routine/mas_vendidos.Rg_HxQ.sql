create procedure mas_vendidos(IN fecha varchar(100))
  begin
    select DATE_FORMAT(M.Fecha,'%Y-%m') Fecha,P.Descripcion_Producto,sum(DM.Cantidad_Producto) as Total from movimientos as M
          inner join detalle_movimientos as DM
                on M.Codigo_Movimiento=DM.Codigo_Movimiento
          inner join productos as P
                on P.Codigo_Producto=DM.Codigo_Producto where M.Fecha like concat(fecha,'%')
    group by P.Descripcion_Producto,DATE_FORMAT(M.Fecha,'%Y-%m') order by Total desc limit 0,30 ;
  end;

