create trigger tr_udpStockVenta
  after INSERT
  on detalle_venta
  for each row
  BEGIN
UPDATE articulo SET stock = stock - NEW.cantidad
WHERE articulo.idarticulo = NEW.idarticulo;
END;

